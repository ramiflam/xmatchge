create database nom;

use nom;
source  C:/Users/USER/Downloads/xmatch_general_a.sql;
