mysqldump: Got error: 1045: Access denied for user 'xmatchge_rami'@'localhost' (using password: YES) when trying to connect
