<html>
<body>
<head>
    <link rel="stylesheet" type="text/css" href="main.css" />
 <br> <br> 
<title>
Xmatch-Genetics new_user </title>
<div class="register-form">
<h1>conditions is ........</h1>

/body>
</html>