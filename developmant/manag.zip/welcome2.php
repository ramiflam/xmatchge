<html>
<body>
<head>
    <link rel="stylesheet" type="text/css" href="main.css" />
 <br> <br> 
<title>
Xmatch-Genetics new_user </title>
<div class="register-form">
<h1>welcome in ........</h1>
<form action="fileLoad.php">
<pre>
<table style="width:50%">
<tr>
<td>Upload a new_file&nbsp;:</td><td><input type="submit" value="Upload"></td>
</tr>
</form> 

<tr>
<form action="fileLoadBulls.php">
<pre>
<table style="width:50%">
<tr>
<td>Upload a bulls file for israel&nbsp;:</td><td><input type="submit" value="Upload"></td>
</tr>
</form> 
<br><br>
<tr>
<form action="new_user.php">
<td>Create a new_user&nbsp;:</td><td><input type="submit" value="New user"></td>
</tr>
</pre>
</form>
<br><br>
<tr>
<form action="settings.php">
<td>settings......&nbsp;:</td><td><input type="submit" value="settings"></td>
</tr>
</table>
</pre>
</form>
</body>
</html>